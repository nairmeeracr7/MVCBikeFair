﻿using Microsoft.Extensions.Configuration;
using MVCBike.Helper;
using MVCBike.Models;
using MVCBike.Repository.Interface;
using System.Collections.Generic;
using System.IO.Enumeration;
using System.Linq;

namespace MVCBike.Repository
{
    public class CompanyRepository : ICompanyRepository
    {
        private readonly IConfiguration _config;
        private HelperClass _helper;
        public CompanyRepository(IConfiguration config)
        {
            _config = config;
            _helper = new HelperClass();
        }
        private List<CompanyModel> companyList = new List<CompanyModel>();
        private List<CompanyModel> GenerateCompanyList()
        {

            for (var i = 0; i <= 100; i++)
            {
                if (_config.GetValue<int>($"Company{i + 1}:Id") > 0)
                {
                CompanyModel company = new CompanyModel();
                company.Id = _config.GetValue<int>($"Company{i + 1}:Id");
                company.Name = _config.GetValue<string>($"Company{i + 1}:Name");
                company.City = _config.GetValue<string>($"Company{i + 1}:City");
                companyList.Add(company);
                }
                else
                    break;
            }
            return companyList;
        }
        public List<CompanyModel> GetAllCompany()
        {
            GenerateCompanyList();
            return companyList;
        }
        /*public List<CompanyModel> EditCompany(int companyId)
        {
            var companys = GenerateCompanyList();
            var company = companys.Find(x => x.Id == companyId);
            company.Name = "edited " + company.Name;
            return companys;
        }*/

        public List<CompanyModel> EditCompany(CompanyModel company)
        {
            var Companys = GenerateCompanyList();
            var Company = Companys.Find(x => x.Id == company.Id);
            Companys.Remove(company);
            _helper.RemoveFromJson(Company.Id, "Company");
            Companys.Add(company);
            _helper.AddtoJson(Company);
            return Companys;
        }
        public bool DeleteCompany(int companyId, out List<CompanyModel> companys)
        {
            companys = GenerateCompanyList();
            companys.Remove(companys.Find(x => x.Id == companyId));
            var company = companys.Find(x => x.Id == companyId);
            if (company == null)
            {
                _helper.RemoveFromJson(companyId, "Company");
                return true;
            }
            else
                return false;
        }
        public List<CompanyModel> AddNewCompany(CompanyModel company)
        {
            var companys = GenerateCompanyList();
            company.Id = companys.Count + 1;
            companys.Add(company);
            _helper.AddtoJson(company);
            return companys;
        }
        /*public List<CompanyModel> Search(string search)
        {
            var companys = GenerateCompanyList();
            var company = companys.Where(x => x.Name == search || search == null).ToList();
            return companys;

            /*var bikes = GenerateBikeList();
            var bike = bikes.Where(x => x.Model.StartsWith(search) || search == null).ToList();
            return bike;
        }*/
        public List<CompanyModel> Search(string search)
        {
            
                var companys = GenerateCompanyList();
                var company = companys.Where(x => x.Name == search || search == null).ToList();
                return company;
        }

        public CompanyModel SearchCompany(int CompanyId)
        {
            var Companys = GenerateCompanyList();
            var Company = Companys.Find(x => x.Id == CompanyId);
            return Company;
        }

        public IEnumerable<CompanyModel> SearchLikeCompany(string company)
        {
            var Companys = GenerateCompanyList();
            var Company = Companys.Where(s => s.Name.Contains(company));
            return Company;
        }

        public IEnumerable<CompanyModel> SearchLikePatternCompany(string pattern)
        {
            var Companys = GenerateCompanyList();
            var Company = Companys.Where(s => FileSystemName.MatchesSimpleExpression(pattern, s.Name));
            return Company;
        }
    }
}
