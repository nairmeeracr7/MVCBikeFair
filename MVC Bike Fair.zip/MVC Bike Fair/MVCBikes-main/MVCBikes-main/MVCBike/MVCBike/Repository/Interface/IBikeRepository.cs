﻿using MVCBike.Models;
using System.Collections.Generic;

namespace MVCBike.Repository.Interface
{
    public interface IBikeRepository
    {
        List<BikeModel> AddNewBike(BikeModel bikeModel);
        List<BikeModel> GetAllBikes();
        List<BikeModel> EditBike(BikeModel bikeModel);
        bool DeleteBike(int bikeId, out List<BikeModel> bikes);
        BikeModel SearchBike(int bikekId);
        IEnumerable<BikeModel> SearchLikeBike(string bikeString);
        IEnumerable<BikeModel> SearchLikePatternBike(string pattern);
        IEnumerable<BikeModel> SearchBikeByCompany(string bikekCompanyId);
    }
}
