﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MVCBike.Models;
using MVCBike.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Enumeration;
using System.Linq;
using System.Threading.Tasks;

namespace MVCBike.Controllers
{
    public class SearchController : Controller
    {
        private readonly ILogger<SearchController> _logger;
        private readonly IBikeRepository _IBikeRepository;
        private readonly ICompanyRepository _ICompanyRepository;
        public SearchController(ILogger<SearchController> logger, IBikeRepository iBikeRepository, ICompanyRepository iCompanyRepository)
        {
            _logger = logger;
            _IBikeRepository = iBikeRepository;
            _ICompanyRepository = iCompanyRepository;
        }
        public IActionResult Index()
        {
            var objSearchModel = new SearchModel();
            objSearchModel.Bikes = _IBikeRepository.GetAllBikes();
            objSearchModel.Companies = _ICompanyRepository.GetAllCompany();
            ViewBag.SearchListItem = objSearchModel.Companies;
            return View(objSearchModel);
        }

        public IActionResult SearchByCompanyId(string searchString)
        {
            if (searchString == null)
            {
                TempData["msg"] = "<script>alert('No company selected');</script>";
                return RedirectToAction("Index");
            }
            var objSearchModel = new SearchModel();
            objSearchModel.SearchString = null;
            var bikes = _IBikeRepository.SearchBikeByCompany(searchString);
            var company = _ICompanyRepository.SearchCompany(Convert.ToInt32(searchString));
            //objSearchModel.Bikes = new List<BikeModel>();
            objSearchModel.Bikes = bikes.ToList();
            objSearchModel.Companies = new List<CompanyModel>();
            objSearchModel.Companies.Add(company);
            ViewBag.SearchListItem = _ICompanyRepository.GetAllCompany();
            return View("Index", objSearchModel);
        }
        public IActionResult SearchByBikeId(string searchString)
        {
            if (searchString == null)
            {
                TempData["msg"] = "<script>alert('No search Input');</script>";
                return RedirectToAction("Index");
            }
            var objSearchModel = new SearchModel();
            objSearchModel.SearchString = null;
            var bikes = _IBikeRepository.GetAllBikes().Where(x => x.Id == Convert.ToInt32(searchString));
            var companies = _ICompanyRepository.GetAllCompany().Where(z => z.Name == (bikes.ToList().Count > 0 ? bikes.ToList()[0].Company : null));
            //objSearchModel.Bikes = new List<BikeModel>();
            objSearchModel.Bikes = bikes.ToList();
            objSearchModel.Companies = new List<CompanyModel>();
            objSearchModel.Companies = companies.ToList();
            if (objSearchModel.Bikes.Count == 0 && objSearchModel.Companies.Count == 0)
            {
                TempData["msg"] = "<script>alert('No search Data Found');</script>";
                return RedirectToAction("Index");
            }
            ViewBag.SearchListItem = _ICompanyRepository.GetAllCompany();
            return View("Index", objSearchModel);
        }

        public IActionResult SearchByCompanyPattern(string searchString)
        {
            if (searchString == null)
            {
                TempData["msg"] = "<script>alert('No search Input');</script>";
                return RedirectToAction("Index");
            }
            var objSearchModel = new SearchModel();
            objSearchModel.SearchString = null;
            var bikes = _IBikeRepository.GetAllBikes().Where(s => FileSystemName.MatchesSimpleExpression($"*{searchString}*", s.Company));
            var companies = _ICompanyRepository.GetAllCompany().Where(s => FileSystemName.MatchesSimpleExpression($"*{searchString}*", s.Name));
            //objSearchModel.Bikes = new List<BikeModel>();
            objSearchModel.Bikes = bikes.ToList();
            objSearchModel.Companies = new List<CompanyModel>();
            objSearchModel.Companies = companies.ToList();
            if (objSearchModel.Bikes.Count == 0 && objSearchModel.Companies.Count == 0)
            {
                TempData["msg"] = "<script>alert('No search Data Found');</script>";
                return RedirectToAction("Index");
            }
            ViewBag.SearchListItem = _ICompanyRepository.GetAllCompany();
            return View("Index", objSearchModel);
        }
    }
}
