﻿namespace MVCBike.Models
{
    public class BikeModel
    {
        public int Id { get; set; }
        public string Company { get; set; }
        public string Model { get; set; }
        public decimal Price { get; set; }
    }
}
