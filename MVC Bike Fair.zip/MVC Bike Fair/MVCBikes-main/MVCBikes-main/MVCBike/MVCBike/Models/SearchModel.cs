﻿using System.Collections.Generic;

namespace MVCBike.Models
{
    public class SearchModel
    {
        public List<BikeModel> Bikes { get; set; }
        public List<CompanyModel> Companies { get; set; }
        public string SearchString { get; set; }
    }
}
